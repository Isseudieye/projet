<?php
        if(isset($_POST["ajouter"])){
            $code=$_POST["code"];
            $nom=$_POST["nom"];
            $description=$_POST["description"];
            $budjet=$_POST["budjet"];
            $date_debut=$_POST["date_debut"];
            $date_fin=$_POST["date_fin"];
            $satut=$_POST["statut"];

            $sql="INSERT INTO projet values(NULL,'$code','$nom','$description', '$budjet', '$date_debut', '$date_fin', '$statut')";
            mysqli_query($connexion,$sql);
            header("location:index.php");

        }
?>  
<div class="col-md-8 offset-2 mt-5">
    <form action="" method="POST">

        <label for=""><code></code></label>
        <input type="unique" name="code" class="form-control">
        <br>
        <label for="">nom</label>
        <input type="text" name="nom" class="form-control">
        <br>
        <label for="">description</label>
        <input type="text" name="description" class="form-control">
        <br>
        <label for="">budjet</label>
        <input type="booléen" name="bujet" class="form-control">
        <br>
        <label for="">date_debut</label>
        <input type="date" name="date_debut" class="form-control">
        <br>
        <label for="">date_fin</label>
        <input type="date" name="date_fin" class="form-control">
        <br>
        <label for="">statut</label>
        <input type="booléen" name="statut" class="form-control">
        <br>
        <button type="submit" name="ajouter" class="btn btn-success">Ajouter</button>
        <button type="submit" name="annuler" class="btn btn-danger">Retour</button>
    </form>
</div>