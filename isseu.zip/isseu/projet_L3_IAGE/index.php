<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <link rel="stylesheet" href="bootstrap.min.css">

</head>
<body>
    <?php
        include 'connexion.php';
   
        

        if(isset($_GET["page"])){

            switch($_GET["page"]){
                case "delete":
                    $id=$_GET["id"];
                    $sql="DELETE FROM projet where id=$id";
                    mysqli_query($connexion,$sql);
                    header("location:index.php");
                    break;
                case "ajouter":
                    require_once("ajouter.php");
                    break;
                case "modifier":
                    $id=$_GET["id"];
                    $sql="SELECT * FROM projet where id=$id";
                    $result=mysqli_query($connexion,$sql);
                    $ligne=mysqli_fetch_row($result);
                    var_dump($ligne);
                    require_once("modifier.php");
                    break;

                case "listeTable":
                    require_once("listeTable.php");



            }
        }else{
            require_once("listeTable.php");
        }
       
        

   ?>
</body>
</html>