<?php
        if(isset($_POST["modifier"])){
            $id=$_POST["id"];
            $code=$_POST["code"];
            $nom=$_POST["nom"];
            $description=$_POST["description"];
            $budjet=$_POST["budjet"];
            $date_debut=$_POST["date_debut"];
            $date_fin=$_POST["date_fin"];
            $satut=$_POST["statut"];
            $sql="UPDATE projet set code='$code', nom='$nom', description='$description', budjet='$budjet', date_debut='$date_debut', date_fin='$date_fin', statut='$statut
            where id=$id";
            mysqli_query($connexion,$sql);
            header("location:index.php");

        }

?>

<div class="col-md-8 offset-2 mt-5">
    <form action="" method="POST">
            <input type="text" name="id" value="<?php echo $ligne[0] ?>" hidden>
        <label for="">code</label>
        <input type="unique" name="code" value="<?php echo $ligne[1] ?>" class="form-control">
        <br>
        <label for="">nom</label>
        <input type="text" name="nom" value="<?php echo $ligne[2] ?>"  class="form-control">
        <br>
        <label for="">description</label>
        <input type="text" name="description" value="<?php echo $ligne[3] ?>" class="form-control">
        <br>
        <label for="">budjet</label>
        <input type="booléen" name="budjet" value="<?php echo $ligne[4] ?>"  class="form-control">
        <br>
        <label for="">date_debut</label>
        <input type="date" name="date_debut" value="<?php echo $ligne[5] ?>"  class="form-control">
        <br>
        <label for="">date_fin</label>
        <input type="date" name="date_fin" value="<?php echo $ligne[6] ?>"  class="form-control">
        <br>
        <label for="">statut</label>
        <input type="booléen" name="statut" value="<?php echo $ligne[7] ?>"  class="form-control">
        <br>
        <button type="submit" name="modifier" class="btn btn-success">Modifier</button>
        
    </form>
</div>